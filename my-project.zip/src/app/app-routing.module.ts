import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { DeptDataGridComponent }   from './deptdatagrid.component';
import { UserDataGridComponent }      from './userdatagrid.component';

const routes: Routes = [
  { path: '', redirectTo: 'usermanager', pathMatch: 'full' },
  { path: 'deptmanager',  component: DeptDataGridComponent },
  { path: 'usermanager', component: UserDataGridComponent }
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],//导入路由组件启动路由
  exports: [ RouterModule ]//导出路由模块
})
export class AppRoutingModule {}