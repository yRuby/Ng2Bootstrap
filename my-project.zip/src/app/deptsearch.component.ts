import { Component, Output, EventEmitter, OnInit } from '@angular/core';
import { AppState } from './app.service';
//import {CookieService} from 'angular2-cookie/core';
@Component({
  selector: 'deptsearch',
  templateUrl: './deptsearch.component.html',
  styleUrls: ['./deptsearch.component.css']
})
export class DeptSearchComponent implements OnInit {
  private deptId="";
  private deptName="";
  @Output() public getSearchData = new EventEmitter<object>();
  //constructor(private _cookieService:CookieService){}
  constructor(private appState:AppState){}
  ngOnInit(){
    //this.deptId=this._cookieService.get("deptId")?this._cookieService.get("deptId"):"";
    //this.deptName=this._cookieService.get("deptName")?this._cookieService.get("deptName"):"";
    if(this.appState.state.hasOwnProperty("DEPTID")){
      this.deptId= this.appState.get("DEPTID");
    }
    if(this.appState.state.hasOwnProperty("DEPTNAME")){
      this.deptName= this.appState.get("DEPTNAME");
    }
    if(this.deptId.trim() + this.deptName.trim()!=""){
      this.search(this.deptId,this.deptName);
    }
  }
  search(id,name){
    this.getSearchData.emit({"id":id,"name":name});
    //this._cookieService.put("deptId",id);
    //this._cookieService.put("deptName",name);
    this.appState.set("DEPTID",id);
    this.appState.set("DEPTNAME",name);
  }
}
