export class Dept{
  id:string;
  name:string;
  isEdit?:boolean;
}