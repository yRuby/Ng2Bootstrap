import { Component, Output, EventEmitter, OnInit } from '@angular/core';
//import {CookieService} from 'angular2-cookie/core';
import { AppState } from './app.service';
@Component({
  selector: 'usersearch',
  templateUrl: './usersearch.component.html',
  styleUrls: ['./usersearch.component.css']
})
export class UserSearchComponent implements OnInit {
  private userId="";
  private userName="";
  private userDate="";
  @Output() public getSearchData = new EventEmitter<object>();
  //constructor(private _cookieService:CookieService){}
  constructor(private appState:AppState){}
  ngOnInit(){
    //this.userId=this._cookieService.get("userId")?this._cookieService.get("userId"):"";
    //this.userName=this._cookieService.get("userName")?this._cookieService.get("userName"):"";
    //this.userDate=this._cookieService.get("userDate")?this._cookieService.get("userDate"):"";
    if(this.appState.state.hasOwnProperty("USERID")){
      this.userId= this.appState.get("USERID");
    }
    if(this.appState.state.hasOwnProperty("USERNAME")){
      this.userName= this.appState.get("USERNAME");
    }
    if(this.appState.state.hasOwnProperty("USERDATE")){
      this.userDate= this.appState.get("USERDATE");
    }
    if(this.userId.trim() + this.userName.trim()+this.userDate.trim()!=""){
      this.search(this.userId,this.userName,this.userDate);
    }
  }
  search(id,name,date){
    this.getSearchData.emit({"id":id,"name":name,"date":date});
    //this._cookieService.put("userId",id);
    //this._cookieService.put("userName",name);
    //this._cookieService.put("userDate",date);
    this.appState.set("USERID",id);
    this.appState.set("USERNAME",name);
    this.appState.set("USERDATE",date);
  }
}
