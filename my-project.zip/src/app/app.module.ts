import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
//import { CookieService } from 'angular2-cookie/services/cookies.service';
import 'hammerjs';
import { MaterialModule } from '@angular/material';
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserSearchComponent } from './usersearch.component';
import { UserDataGridComponent } from './userdatagrid.component';
import { PageComponent } from './page.component';
import { UserService } from './user.service';
import { DeptSearchComponent } from './deptsearch.component';
import { DeptDataGridComponent } from './deptdatagrid.component';
import { DeptService } from './dept.service';
import { AppState } from './app.service';

@NgModule({
  declarations: [
    AppComponent,
    UserSearchComponent,
    UserDataGridComponent,
    DeptSearchComponent,
    DeptDataGridComponent,
    PageComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    MaterialModule.forRoot(),
    BrowserAnimationsModule,
    AppRoutingModule
  ],
  providers: [AppState, UserService, DeptService],//CookieService
  bootstrap: [AppComponent]
})
export class AppModule { }
