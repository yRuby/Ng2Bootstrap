import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = '员工管理系统';
  colorUserBtn='primary';
  colorDeptBtn='';
  ngOnInit() {
    if(location.href.indexOf("user")>=0){
      this.colorUserBtn='primary';
      this.colorDeptBtn='';
    }else if(location.href.indexOf("dept")>=0){
      this.colorUserBtn='';
      this.colorDeptBtn='primary';
    }
  }
  btnClick(btn){
    if(btn==="user"){
      this.colorUserBtn='primary';
      this.colorDeptBtn='';
    }else if(btn==="dept"){
      this.colorUserBtn='';
      this.colorDeptBtn='primary';
    }
  }
}
