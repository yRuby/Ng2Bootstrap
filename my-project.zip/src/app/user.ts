export class User{
  id:string;
  name:string;
  date:string;
  dept:string;
  isEdit?:boolean;
}