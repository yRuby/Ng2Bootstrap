import { Component, OnInit } from '@angular/core';
import { Dept } from './dept';
import { AppState } from './app.service';
import { DeptService } from './dept.service';
@Component({
  selector: 'deptdatagrid',
  templateUrl: './deptdatagrid.component.html',
  styleUrls: ['./deptdatagrid.component.css']
})
export class DeptDataGridComponent implements OnInit {
  pagetitle="部门管理";
  tiles = ['ID','部门名称',''];
  currPageDepts:Dept[]=[];
  editDept:Dept;
  allDepts:Dept[];
  currPage:number=1;
  pageSize:number=5;
  totalPageNum:number;
  constructor(private appState:AppState, private DeptService: DeptService) { }
  ngOnInit(){
    if(this.appState.state.hasOwnProperty('DEPTPAGE')) {
      this.currPage=this.appState.get("DEPTPAGE");
    }
    this.getAllData();
  }
  public getPageData(idx: number) {
    this.currPage=idx;
    if(this.currPage>this.totalPageNum){
      this.currPage=1;
    }
    this.appState.set("DEPTPAGE",this.currPage);
    let s=(this.currPage - 1) * this.pageSize;
    let e=this.currPage * this.pageSize;
    this.currPageDepts = this.allDepts.slice(s, e);
    this.currPageDepts.forEach(d=>d.isEdit=false);
  }
  public getAllData() {
    if(this.appState.state.hasOwnProperty('DEPTS')) {
      this.allDepts = this.appState.get('DEPTS');
      this.totalPageNum=Math.floor((this.allDepts.length+this.pageSize-1)/this.pageSize); 
      this.getPageData(this.currPage);
    } else {
      this.DeptService.getDepts()
      .then((depts) => {
        this.appState.set('DEPTS', depts);
        this.allDepts = depts;
        this.totalPageNum=Math.floor((depts.length+this.pageSize-1)/this.pageSize); 
        this.getPageData(this.currPage);
      }).catch((err) => { return false; });
    }
  }
  getSearchData(searchKey){// 搜索
    this.allDepts = this.appState.get('DEPTS');
    this.allDepts=this.allDepts.filter(item=>{
      let mid=true;
      if(searchKey.id.trim()!==""){
        mid=item.id.indexOf(searchKey.id.trim())>-1; 
      }
      let mname=true;
      if(searchKey.name.trim()!==""){
          mname=item.name.indexOf(searchKey.name.trim())>-1;
      }
      return mid && mname;
    });
    this.totalPageNum=Math.floor((this.allDepts.length+this.pageSize-1)/this.pageSize); 
    this.getPageData(this.currPage);
  }
  edit(i){
    for(let j=0;j<this.currPageDepts.length;j++){
      this.currPageDepts[j].isEdit=false;
    }
    this.currPageDepts[i].isEdit=true;
    this.editDept=JSON.parse(JSON.stringify(this.currPageDepts[i]));
  }
  save(i){
    /// this.DeptService.update(this.currPageDepts[i])
      /// .then(() => {
        this.currPageDepts[i].isEdit=false;
        this.allDepts[this.currPage*this.pageSize-this.pageSize+i]=JSON.parse(JSON.stringify(this.currPageDepts[i]));
        this.appState.set('DEPTS', this.allDepts);
        this.editDept=new Dept();
      /// }).catch((err) => { return false; });
    // console.log(JSON.stringify(this.allDepts));
    // console.log(JSON.stringify(this.currPageDepts));
  }
  cancel(i){
    this.currPageDepts[i]=JSON.parse(JSON.stringify(this.editDept));
    this.currPageDepts[i].isEdit=false;
  }
  delete(i){
    if(confirm("您确定要删除吗？")){
      /// this.DeptService.delete(this.currPageDepts[i].id)
      /// .then(() => {
        this.currPageDepts.splice(i,1);
        this.allDepts.splice(this.currPage*this.pageSize-this.pageSize+i,1);
        this.appState.set('DEPTS', this.allDepts);
      /// }).catch((err) => { return false; });
      // console.log(JSON.stringify(this.allDepts));
      // console.log(JSON.stringify(this.currPageDepts));  
    }
  }
  addDept(){
     /// this.DeptService.create(new Dept())
      /// .then(() => {
        let blankDept={'id':'','name':'','isEdit':true};
        this.currPageDepts.push(blankDept);
        let i=this.currPage*this.pageSize-this.pageSize+this.currPageDepts.length-1;
        this.allDepts.splice(i,0,{'id':'','name':'','isEdit':true});
        this.appState.set('DEPTS', this.allDepts);
        this.editDept=new Dept();
      /// }).catch((err) => { return false; });

    
    
    // console.log(JSON.stringify(this.allDepts));
    // console.log(JSON.stringify(this.currPageDepts));
  }
}

